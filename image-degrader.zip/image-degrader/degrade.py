"""
Image Quality Degrader
Converts high-quality images into low-quality versions using
realistic compression and degradation techniques.
"""

import io
import argparse
from pathlib import Path
from PIL import Image, ImageFilter
import numpy as np


class ImageDegrader:
    def __init__(self, jpeg_quality=15, downscale_factor=4,
                 blur_radius=0.6, add_noise=True, noise_level=10,
                 posterize_bits=4, block_artifacts=True):
        self.jpeg_quality = jpeg_quality
        self.downscale_factor = downscale_factor
        self.blur_radius = blur_radius
        self.add_noise = add_noise
        self.noise_level = noise_level
        self.posterize_bits = posterize_bits
        self.block_artifacts = block_artifacts

    def degrade(self, image: Image.Image) -> Image.Image:
        img = image.convert("RGB")

        # 1. Downscale then upscale (loses fine detail)
        if self.downscale_factor > 1:
            w, h = img.size
            small = img.resize(
                (max(1, w // self.downscale_factor),
                 max(1, h // self.downscale_factor)),
                Image.BILINEAR,
            )
            img = small.resize((w, h), Image.NEAREST if self.block_artifacts
                               else Image.BILINEAR)

        # 2. Slight blur
        if self.blur_radius > 0:
            img = img.filter(ImageFilter.GaussianBlur(self.blur_radius))

        # 3. Posterization (reduce color depth)
        if self.posterize_bits < 8:
            img = img.quantize(colors=2 ** self.posterize_bits).convert("RGB")

        # 4. Add noise
        if self.add_noise:
            arr = np.array(img).astype(np.int16)
            noise = np.random.normal(0, self.noise_level, arr.shape)
            arr = np.clip(arr + noise, 0, 255).astype(np.uint8)
            img = Image.fromarray(arr)

        # 5. Aggressive JPEG recompression
        buf = io.BytesIO()
        img.save(buf, format="JPEG", quality=self.jpeg_quality)
        buf.seek(0)
        img = Image.open(buf).convert("RGB")

        return img


def main():
    parser = argparse.ArgumentParser(description="Degrade image quality")
    parser.add_argument("input", help="Input image path or directory")
    parser.add_argument("-o", "--output", default="output", help="Output dir")
    parser.add_argument("--quality", type=int, default=15, help="JPEG quality (1-95)")
    parser.add_argument("--factor", type=int, default=4, help="Downscale factor")
    parser.add_argument("--blur", type=float, default=0.6, help="Blur radius")
    parser.add_argument("--noise", type=int, default=10, help="Noise level")
    parser.add_argument("--bits", type=int, default=4, help="Posterize color bits")
    args = parser.parse_args()

    degrader = ImageDegrader(
        jpeg_quality=args.quality,
        downscale_factor=args.factor,
        blur_radius=args.blur,
        noise_level=args.noise,
        posterize_bits=args.bits,
    )

    inp = Path(args.input)
    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)

    exts = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}
    files = [inp] if inp.is_file() else [
        p for p in inp.rglob("*") if p.suffix.lower() in exts
    ]

    for f in files:
        try:
            img = Image.open(f)
            result = degrader.degrade(img)
            dest = out / f"{f.stem}_lowq.jpg"
            result.save(dest, quality=args.quality)
            print(f"✓ {f.name} → {dest.name}")
        except Exception as e:
            print(f"✗ {f.name}: {e}")


if __name__ == "__main__":
    main()